#ifndef BUTTONS_H
#define BUTTONS_H
#include <Arduino.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include "sounds.h"

extern volatile bool gameStart;
extern volatile bool buttonWasPressed;
extern volatile int buttonNumber;
const byte firstPin = 2; // First PinChangeInterrupt on D-bus
const byte lastPin =  6; // Last PinChangeInterrupt on D-bus  
const byte startPin = 6;  

/* 
  initButtonsAndButtonInterrupts subroutine is called from Setup() function
  during the initialization of Speden Spelit. This function does the following:
  1) Initializes 4 button pins for the game = Arduino pins 2,3,4,5
  2) Initializes 1 button pin for starting the game = Aruino pin 6
  3) Enables PinChangeInterrupt on D-bus in a way that interrupt
     is generated whenever some of pins 2,3,4,5,6 is connected to LOW state
*/

void initButtonsAndButtonInterrupts(void);
int pressedButton();
void testButtons();
bool checkGameStart();

// Introduce PCINT2_vect Interrupt SeRvice (ISR) function for Pin Change Interrupt.
ISR(PCINT2_vect);
#endif